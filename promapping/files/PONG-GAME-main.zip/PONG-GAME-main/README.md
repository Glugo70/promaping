# PONG-GAME

 👉🏻 It is a simple Pong Game in Python using Pygame.
 
---

<p align="center"> <b> 👉🏻 Created to learn Pygame 👈🏻 <b> </p>
 
<p align="center"><a href='https://github.com/Amey-Thakur/COMPUTER-ENGINEERING', style='color: greenyellow;'> ✌🏻 Back To Engineering ✌🏻</p>
